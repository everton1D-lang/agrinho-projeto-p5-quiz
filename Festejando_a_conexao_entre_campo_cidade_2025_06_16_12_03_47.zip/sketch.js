// 📦 Base de Dados de Perguntas
let perguntas = [
  {
    texto: "Qual produto que você consome diariamente vem diretamente do campo?",
    opcoes: ["Smartphone", "Leite", "Internet", "Plástico"],
    resposta: 1
  },
  {
    texto: "Como a cidade ajuda o campo a se desenvolver?",
    opcoes: [
      "Enviando lixo para o campo",
      "Comprando produtos agrícolas",
      "Desmatando florestas",
      "Evitando o consumo"
    ],
    resposta: 1
  },
  {
    texto: "O que é agroecologia?",
    opcoes: [
      "Uso de agrotóxicos",
      "Sistema sustentável de produção",
      "Urbanização do campo",
      "Tecnologia para mineração"
    ],
    resposta: 1
  },
  {
    texto: "Qual destes é um exemplo de produto rural?",
    opcoes: ["Camiseta", "Queijo", "Computador", "Cimento"],
    resposta: 1
  },
  {
    texto: "O que o campo oferece para a cidade?",
    opcoes: ["Internet", "Alimentos", "Saneamento", "Serviços bancários"],
    resposta: 1
  },
  {
    texto: "O que a cidade oferece para o campo?",
    opcoes: ["Tecnologia", "Sementes", "Sol", "Chuva"],
    resposta: 0
  },
  {
    texto: "Qual alternativa representa um problema no campo?",
    opcoes: ["Crescimento populacional", "Êxodo rural", "Exportação", "Plantio de alimentos"],
    resposta: 1
  },
  {
    texto: "A cidade depende do campo principalmente para:",
    opcoes: ["Energia elétrica", "Água encanada", "Alimentação", "Roupas de marca"],
    resposta: 2
  },
  {
    texto: "Qual dessas profissões está mais ligada ao campo?",
    opcoes: ["Agricultor", "Engenheiro civil", "Desenvolvedor", "Vendedor de shopping"],
    resposta: 0
  },
  {
    texto: "Como a tecnologia pode ajudar o campo?",
    opcoes: ["Com redes sociais", "Com maquinários e técnicas agrícolas", "Com videogames", "Com apps de transporte"],
    resposta: 1
  },
  {
    texto: "A urbanização do campo pode causar:",
    opcoes: ["Melhoria de colheitas", "Desemprego", "Perda de áreas agrícolas", "Mais acesso à saúde"],
    resposta: 2
  },
  {
    texto: "O transporte de alimentos do campo para a cidade depende de:",
    opcoes: ["Rios", "Animais", "Estradas e caminhões", "Internet"],
    resposta: 2
  },
  {
    texto: "Como valorizar o campo na cidade?",
    opcoes: ["Consumindo produtos locais", "Evitando feiras", "Comprando industrializados", "Importando alimentos"],
    resposta: 0
  },
  {
    texto: "O que significa 'êxodo rural'?",
    opcoes: ["Entrada de turistas no campo", "Saída de pessoas do campo para a cidade", "Imigração estrangeira", "Migração urbana para o campo"],
    resposta: 1
  },
  {
    texto: "Como a educação pode melhorar a vida no campo?",
    opcoes: ["Oferecendo cursos agrícolas", "Aumentando impostos", "Reduzindo plantações", "Cortando internet"],
    resposta: 0
  }
];

// 🔄 Variáveis de Estado do Quiz
let perguntaAtual = 0; // Índice da pergunta atual
let opcaoSelecionada = -1; // Índice da opção selecionada
let mostrarResultado = false; // Flag para mostrar os resultados
let pontuacao = 0; // Armazena a pontuação
let showStartScreen = true; // Flag para exibir a tela inicial

// 🖼️ Função de Configuração Inicial
function setup() {
  createCanvas(800, 550); // Cria o canvas para o quiz
  textAlign(CENTER, CENTER); // Alinha o texto ao centro
  textSize(18); // Define o tamanho inicial do texto
}

// 🔁 Função de Loop de Renderização Principal
function draw() {
  background(200, 240, 200); // Define o fundo do quiz

  if (showStartScreen) {
    drawStartScreen(); // Se for a tela inicial, chama a função correspondente
  } else if (mostrarResultado) {
    drawResult(); // Se for a tela de resultado, chama a função correspondente
  } else {
    drawQuiz(); // Caso contrário, exibe as perguntas do quiz
  }
}

// 🧩 Função para Desenhar a Tela Inicial
function drawStartScreen() {
  fill(0); // Cor do texto
  textSize(32); // Tamanho do texto
  text("🎉 Festejando a Conexão Campo-Cidade 🎉", width / 2, 70); // Exibe o título

  textSize(20);
  text("Este quiz celebra os laços entre o mundo rural e urbano!", width / 2, 120); // Descrição do quiz

  textSize(18);
  text("🧠 Como jogar:", width / 2, 170); // Explicação do que fazer
  text(". Leia cada pergunta com atenção", width / 2, 200);
  text(". Clique na alternativa correta", width / 2, 230);
  text(". Veja sua pontuação ao final", width / 2, 260);

  textSize(16);
  text("👉 Clique no botão abaixo para começar!", width / 2, 300);

  fill(100, 200, 100); // Cor do botão
  rect(width / 2 - 75, 340, 150, 50, 10); // Botão de início
  fill(0);
  textSize(20);
  text("Iniciar Quiz", width / 2, 365); // Texto do botão
}

// ❓ Função para Desenhar as Perguntas do Quiz
function drawQuiz() {
  let q = perguntas[perguntaAtual]; // Obtém a pergunta atual

  textSize(22);
  fill(0);
  text("Pergunta " + (perguntaAtual + 1) + " de " + perguntas.length, width / 2, 40); // Exibe a numeração da pergunta
  textSize(20);
  text(q.texto, width / 2, 90); // Exibe o texto da pergunta

  // Desenha as opções de resposta
  for (let i = 0; i < q.opcoes.length; i++) {
    if (i === opcaoSelecionada) {
      fill(100, 200, 100); // Cor de fundo para a opção selecionada
    } else {
      fill(255); // Cor de fundo das opções não selecionadas
    }
    rect(150, 140 + i * 60, 500, 40, 10); // Caixa de cada opção
    fill(0);
    text(q.opcoes[i], width / 2, 160 + i * 60); // Exibe o texto da opção
  }

  // Instrução para o usuário
  textSize(14);
  fill(0);
  text("Clique para selecionar sua resposta", width / 2, height - 30);
}

// 🏁 Função para Exibir o Resultado Final
function drawResult() {
  textSize(28);
  fill(0);
  text("🎊 Quiz finalizado! 🎊", width / 2, 150); // Exibe título de resultado
  textSize(22);
  text("Você acertou " + pontuacao + " de " + perguntas.length + " perguntas!", width / 2, 200); // Exibe a pontuação final
}

// 🖱️ Função para Gerenciar Interação com o Mouse
function mousePressed() {
  // Clique na tela inicial para iniciar o quiz
  if (showStartScreen) {
    if (
      mouseX > width / 2 - 75 &&
      mouseX < width / 2 + 75 &&
      mouseY > 340 &&
      mouseY < 390
    ) {
      showStartScreen = false; // Inicia o quiz
    }
    return;
  }

  // Não faz nada se já estiver exibindo o resultado
  if (mostrarResultado) return;

  let q = perguntas[perguntaAtual]; // Obtém a pergunta atual

  // Verifica se uma opção foi clicada
  for (let i = 0; i < q.opcoes.length; i++) {
    if (
      mouseX > 150 && mouseX < 650 &&
      mouseY > 140 + i * 60 &&
      mouseY < 180 + i * 60
    ) {
      opcaoSelecionada = i; // Armazena a opção clicada
    }
  }

  // Verifica se a resposta está correta
  if (opcaoSelecionada === q.resposta) {
    pontuacao++; // Incrementa a pontuação se a resposta estiver correta
  }

  // Avança para a próxima pergunta após um pequeno delay
  setTimeout(() => {
    perguntaAtual++; // Avança para a próxima pergunta
    opcaoSelecionada = -1; // Reseta a opção selecionada

    // Se não houver mais perguntas, exibe o resultado
    if (perguntaAtual >= perguntas.length) {
      mostrarResultado = true;
    }
  }, 300); // Delay de 300ms para a transição
}
